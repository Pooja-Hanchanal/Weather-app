//this is the header component
import Register from './register';
import Welcome from './Welcome';
import { Link, Switch, Route, UseHistory, UseLocation, useHistory, useLocation } from "react-router-dom";
import Login from './LoginPage';

import './Topnav.css'


import React, { Component } from 'react';



function Logout() {

  
    return (
        
       
        <Login>
        </Login> 
         
        
    );
  }
  
  export default Logout;
  