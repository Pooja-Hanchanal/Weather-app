import React, { Component } from "react"
import "./css/App1.css"
import { Link, Switch, Route, UseHistory, UseLocation, useHistory, useLocation } from "react-router-dom";

import SearchBar from "./components/SearchBar"
import WeatherCard from "./components/WeatherCard"
import Favourites from "./components/Favourites"
import API_KEY from "./config"
class App extends Component {
  constructor(props) {
    super(props)
    this.state = {
      weatherData: {
        weather: "",
        city: "",
        country: "",
        temp: 0
      },
      searchDone: false,
      savedCities: [],
      hasSavedCities: false,
      errorMessage: ""
    }

    this.callWeatherData = this.callWeatherData.bind(this)
    this.updateSavedCities = this.updateSavedCities.bind(this)
  }

  callWeatherData(city) {
    const url =   `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=fe4feefa8543e06d4f3c66d92c61b69c`
    fetch(url)
      .then(handleErrors)
      .then(resp => resp.json())
      .then(data => {
        const weatherObj = {
          weather: data.weather,
          city: data.name,
          country: data.sys.country,
          temp: data.main.temp,
          main: data.main,
          wind: data.wind,
          humidity: data.main.humidity,
          wind_direction: data.wind.deg,
          pressure: data.main.pressure,
          sunrise: data.sys.sunrise,
          visibility: data.visibility,
          sunset: data.sys.sunset
        }
        
        this.setState({
          weatherData: weatherObj,
          searchDone: true,
          errorMessage: ""
        })
      })
      .catch(error => {
        // If an error is catch, it's sent to SearchBar as props
        this.setState({ errorMessage: error.message })
      })

    function handleErrors(response) {
      if (!response.ok) {
        throw Error(response.statusText)
      }
      return response
    }
  }
 

  updateSavedCities(cityArr) {
    // hasCities is set to true if length is more than 0, otherwise false
    const hasCities = cityArr.length > 0
    this.setState({ savedCities: cityArr, hasSavedCities: hasCities })
  }

  componentWillMount() {
    // See if there's saved cities in localStorage before the App is mounted
    // Tests didn't like parsing when localStorage.getItem was undefined, so this was my solution for it
    let existingCities = JSON.parse(localStorage.getItem("cityList") || "[]")

    if (existingCities.length !== 0) {
      this.setState({
        hasSavedCities: true,
        savedCities: existingCities
      })
    }
  }
  delLock = () => {
    const lock = "false"
   localStorage.setItem("lock1",lock)
  };

  render() {
    const {
      searchDone,
      weatherData,
      hasSavedCities,
      savedCities,
      errorMessage
    } = this.state
    
    return (
      <div className="App">
        <nav > 
    
            <Link to="/login" className='btn btn-outline-danger' style={{float:"right"}} onClick={() =>this.delLock()}>Logout</Link>
          </nav>
        <SearchBar
          callBackFromParent={this.callWeatherData}
          error={errorMessage}
        />
        {searchDone && (
          <WeatherCard
            weatherData={weatherData}
            savedCities={savedCities}
            callBackFromParent={this.updateSavedCities}
          />
        )}
        {hasSavedCities && (
          <Favourites
            savedCities={savedCities}
            callBackFromParent={this.callWeatherData}
          />
        )}
        
 
     
      </div>
      
 
    )
  }
}


export default App

