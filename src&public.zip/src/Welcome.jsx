//this is the main page

import React from 'react';
import background from "./images/bg.jpg";
import Navbar from './Navbar';


import Register from './register';

class Welcome extends React.Component {
  
  render() {
    
    const myStyle={
      backgroundImage: `url(${background})`,
      height:'100vh',
      backgroundSize: 'cover',
      backgroundRepeat: 'no-repeat',
  };
    return (
      <div style={myStyle}>
        <div>
        {/* <h1>hello,{this.props.location.user}</h1> */}
        <Navbar>

        </Navbar>
        </div>
      </div>
    )
  }
}

export default Welcome;