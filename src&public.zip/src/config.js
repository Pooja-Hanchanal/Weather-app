const API_KEY =  `fe4feefa8543e06d4f3c66d92c61b69c`
export default API_KEY;