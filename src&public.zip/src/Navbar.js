//this is for the center logo thats it

import React, { Component } from 'react';
import Login from './LoginPage';
import { Link, Switch, Route, UseHistory, UseLocation, useHistory, useLocation } from "react-router-dom";
import Register from './register';
import logo from "./images/logo.jpg";



function Navbar() {
    const history=useHistory();
    const location = useLocation();
    return (
        <div> 
                  <img src={logo} alt="logo" className="center" style={{height:'50%' ,width:'25%' , marginTop:'15%'}}></img>
      </div>
    );
  }

export default Navbar